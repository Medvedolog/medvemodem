<!-- Insert after the header navigation links in the main README. -->

**[Screenshots / Скриншоты интерфейса](screenshots/README.md)**

[![MedveModem LuCI — карточки модемов, резервирование и состояние соединения](screenshots/01-modems-cards.png)](screenshots/README.md)
